"""
Estado: EN JUEGO
Maneja toda la lÃ³gica del juego principal
"""

import copy
import pygame
from game import constants
from game.drawing import (dibujar_tablero, dibujar_piezas, dibujar_resaltados, dibujar_ui,
                          dibujar_numeros_flotantes, dibujar_animacion_activa, dibujar_proyectiles,
                          dibujar_borde_turno, obtener_boton_volver, obtener_boton_deshacer, obtener_boton_pasar)
from game.turn_queue_display import dibujar_panel_turnos
from game.logic import calcular_casillas_posibles, calcular_ataques_posibles, verificar_ganador
from game.effects import (DamageText, MoveAnimation, MeleeAttackAnimation,
                          FadeOutAnimation, ProjectileAnimation)
from game.audio import get_audio


def manejar_estado_en_juego(pantalla, tablero, turn_manager, turn_queue, historial_turnos, 
                             numeros_flotantes, animaciones_muerte, CACHE_IMAGENES,
                             fuente_hp, fuente_damage):
    """
    Maneja el estado del juego principal.
    
    Returns:
        tuple: (nuevo_estado, datos_actualizados)
        donde datos_actualizados es un dict con:
        - pieza_activa
        - movimientos_resaltados
        - ataques_resaltados
        - ganador
        - animacion_en_curso
        - superficie_blur (para confirmaciÃ³n)
    """
    
    # Estado local del juego
    pieza_activa = None
    movimientos_resaltados = []
    ataques_resaltados = []
    ganador = None
    animacion_en_curso = None
    superficie_blur = None
    
    audio = get_audio()
    
    def finalizar_turno():
        """Finaliza el turno actual y prepara el siguiente."""
        nonlocal pieza_activa, movimientos_resaltados, ataques_resaltados, ganador
        
        estado_actual = {
            'tablero': copy.deepcopy(tablero),
            'piezas_en_juego': copy.deepcopy(turn_manager.piezas_en_juego),
            'reloj': turn_manager.reloj,
            'cola_turnos': [p.posicion for p in turn_queue.queue if p and p.esta_viva()],
        }
        historial_turnos.append(estado_actual)
        if len(historial_turnos) > 5:
            historial_turnos.pop(0)
        
        
        # CRÍTICO: Verificar ganador ANTES de calcular siguiente turno
        resultado = verificar_ganador(turn_manager.piezas_en_juego)
        if resultado is not None:
            ganador = resultado
            return 'fin_del_juego'
        
        # Solo calcular siguiente turno si el juego no ha terminado
        if pieza_activa:
            pieza_activa.calcular_siguiente_turno(turn_manager.reloj)
        
        # Avanzar la cola de turnos
        turn_queue.advance_turn()
        
        pieza_activa = None
        movimientos_resaltados = []
        ataques_resaltados = []
        return 'en_juego'
    
    # Loop principal del estado
    reloj = pygame.time.Clock()
    
    while True:
        # --- ActualizaciÃ³n de estado ---
        if animacion_en_curso:
            terminada = animacion_en_curso.update()
            if terminada:
                entidad_ended = animacion_en_curso.entidad
                
                if isinstance(animacion_en_curso, MoveAnimation):
                    if entidad_ended.tipo_turno > 0 and not entidad_ended.ha_atacado:
                        ataques_resaltados = calcular_ataques_posibles(entidad_ended, tablero)
                        if not ataques_resaltados:
                            nuevo_estado = finalizar_turno()
                            if nuevo_estado == 'fin_del_juego':
                                return (nuevo_estado, {
                                    'pieza_activa': pieza_activa,
                                    'movimientos_resaltados': movimientos_resaltados,
                                    'ataques_resaltados': ataques_resaltados,
                                    'ganador': ganador,
                                    'animacion_en_curso': animacion_en_curso,
                                    'superficie_blur': superficie_blur
                                })
                    else:
                        finalizar_turno()
                
                elif isinstance(animacion_en_curso, (MeleeAttackAnimation, ProjectileAnimation)):
                    # CRÃTICO: Verificar ganador INMEDIATAMENTE después del ataque
                    resultado = verificar_ganador(turn_manager.piezas_en_juego)
                    # Limpiar piezas muertas de la cola
                    turn_queue.remove_dead_pieces()
                    if resultado is not None:
                        ganador = resultado
                        animacion_en_curso = None
                        return ('fin_del_juego', {
                            'pieza_activa': pieza_activa,
                            'movimientos_resaltados': movimientos_resaltados,
                            'ataques_resaltados': ataques_resaltados,
                            'ganador': ganador,
                            'animacion_en_curso': None,
                            'superficie_blur': superficie_blur
                        })
                    
                    if entidad_ended.tipo_turno == 2 and not entidad_ended.ha_movido:
                        movimientos_resaltados = calcular_casillas_posibles(entidad_ended, tablero)
                        if not movimientos_resaltados:
                            nuevo_estado = finalizar_turno()
                            if nuevo_estado == 'fin_del_juego':
                                return (nuevo_estado, {
                                    'pieza_activa': pieza_activa,
                                    'movimientos_resaltados': movimientos_resaltados,
                                    'ataques_resaltados': ataques_resaltados,
                                    'ganador': ganador,
                                    'animacion_en_curso': animacion_en_curso,
                                    'superficie_blur': superficie_blur
                                })
                    else:
                        finalizar_turno()
                
                animacion_en_curso = None
        
        for animacion in list(animaciones_muerte):
            if animacion.update():
                animaciones_muerte.remove(animacion)
        
        for numero in numeros_flotantes:
            numero.update()
        numeros_flotantes[:] = [n for n in numeros_flotantes if n.lifetime > 0]
        
        if pieza_activa is None and not animacion_en_curso:
            while pieza_activa is None:
                pieza_encontrada = turn_queue.get_current_piece()
                if pieza_encontrada:
                    pieza_activa = pieza_encontrada
                    pieza_activa.reiniciar_estado_turno()
                    movimientos_resaltados = calcular_casillas_posibles(pieza_activa, tablero)
                    ataques_resaltados = calcular_ataques_posibles(pieza_activa, tablero)
                    break
        
        # --- Manejo de Eventos ---
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return ('saliendo', {
                    'pieza_activa': pieza_activa,
                    'movimientos_resaltados': movimientos_resaltados,
                    'ataques_resaltados': ataques_resaltados,
                    'ganador': ganador,
                    'animacion_en_curso': animacion_en_curso,
                    'superficie_blur': superficie_blur
                })
            
            if evento.type == pygame.MOUSEBUTTONDOWN and pieza_activa and not animacion_en_curso:
                pos_clic = evento.pos
                
                # Obtener rectÃ¡ngulos de botones con offsets aplicados
                BOTON_VOLVER = obtener_boton_volver()
                BOTON_DESHACER = obtener_boton_deshacer()
                BOTON_PASAR = obtener_boton_pasar()
                
                if BOTON_VOLVER.collidepoint(pos_clic):
                    print("Volviendo al menÃº principal...")
                    copia_pantalla = pantalla.copy()
                    ancho_real = pantalla.get_width()
                    alto_real = pantalla.get_height()
                    pequena = pygame.transform.smoothscale(copia_pantalla, (ancho_real // 10, alto_real // 10))
                    superficie_blur = pygame.transform.scale(pequena, (ancho_real, alto_real))
                    velo_oscuro = pygame.Surface((ancho_real, alto_real), pygame.SRCALPHA)
                    velo_oscuro.fill((0, 0, 0, 150))
                    superficie_blur.blit(velo_oscuro, (0, 0))
                    return ('confirmacion_salir', {
                        'pieza_activa': pieza_activa,
                        'movimientos_resaltados': movimientos_resaltados,
                        'ataques_resaltados': ataques_resaltados,
                        'ganador': ganador,
                        'animacion_en_curso': animacion_en_curso,
                        'superficie_blur': superficie_blur
                    })
                
                elif BOTON_DESHACER.collidepoint(pos_clic):
                    if historial_turnos:
                        print("Deshaciendo el Ãºltimo movimiento...")
                        estado_anterior = historial_turnos.pop()
                        
                        # Restaurar datos bÃ¡sicos
                        tablero[:] = estado_anterior['tablero']
                        turn_manager.piezas_en_juego = estado_anterior['piezas_en_juego'][:]
                        turn_manager.reloj = estado_anterior['reloj']
                        
                        # Reconstruir el tablero desde piezas_en_juego
                        for fila in range(constants.FILAS):
                            for col in range(constants.COLUMNAS):
                                tablero[fila][col] = None
                        
                        for pieza in turn_manager.piezas_en_juego:
                            fila, col = pieza.posicion
                            tablero[fila][col] = pieza
                        
                        # Limpiar piezas muertas
                        for fila in range(constants.FILAS):
                            for col in range(constants.COLUMNAS):
                                pieza = tablero[fila][col]
                                if pieza is not None and pieza.hp <= 0:
                                    tablero[fila][col] = None
                        
                        # CRÍTICO: Reconstruir la cola de turnos con el estado restaurado
                        posiciones_cola = estado_anterior.get('cola_turnos', [])
                        turn_queue.queue = []
                        for pos in posiciones_cola:
                            if 0 <= pos[0] < constants.FILAS and 0 <= pos[1] < constants.COLUMNAS:
                                pieza = tablero[pos[0]][pos[1]]
                                if pieza and pieza.esta_viva():
                                    turn_queue.queue.append(pieza)
                        
                        # Resetear estado visual
                        pieza_activa = None
                        animacion_en_curso = None
                        numeros_flotantes.clear()
                        animaciones_muerte.clear()
                        movimientos_resaltados.clear()
                        ataques_resaltados.clear()
                    else:
                        print("No hay movimientos para deshacer.")
                
                elif BOTON_PASAR.collidepoint(pos_clic):
                    print("Pasando turno...")
                    finalizar_turno()
                
                # CRÃTICO: Convertir coordenadas de mouse a casilla del tablero
                # Restar offsets ANTES de calcular la casilla
                else:
                    # Coordenadas relativas al tablero (sin offsets)
                    x_relativo = pos_clic[0] - constants.OFFSET_X
                    y_relativo = pos_clic[1] - constants.OFFSET_Y - constants.UI_ALTO
                    
                    # Verificar que el clic estÃ¡ dentro del tablero
                    if x_relativo >= 0 and y_relativo >= 0:
                        col_clic = x_relativo // constants.TAMANO_CASILLA
                        fila_clic = y_relativo // constants.TAMANO_CASILLA
                        
                        # Verificar que la casilla estÃ¡ dentro de los lÃ­mites
                        if 0 <= fila_clic < constants.FILAS and 0 <= col_clic < constants.COLUMNAS:
                            if (fila_clic, col_clic) in ataques_resaltados:
                                if not pieza_activa.ha_atacado:
                                    pieza_atacada = tablero[fila_clic][col_clic]
                                    
                                    def aplicar_dano_callback():
                                        print(f"{pieza_activa.nombre} impacta a {pieza_atacada.nombre}.")
                                        if pieza_activa.tipo_ataque == 'ranged':
                                            audio.play_ranged_impact()
                                        
                                        pieza_atacada.recibir_dano(pieza_activa.atk)
                                        
                                        # Calcular posiciÃ³n en pÃ­xeles CON offsets
                                        centro_x = constants.OFFSET_X + col_clic * constants.TAMANO_CASILLA + constants.TAMANO_CASILLA / 2
                                        centro_y = constants.OFFSET_Y + fila_clic * constants.TAMANO_CASILLA + constants.UI_ALTO + constants.TAMANO_CASILLA / 2
                                        pos_damage = (centro_x, centro_y + (0.05 * constants.TAMANO_CASILLA))
                                        nuevo_numero = DamageText(pieza_activa.atk, pos_damage, fuente_damage)
                                        numeros_flotantes.append(nuevo_numero)
                                        
                                        if not pieza_atacada.esta_viva():
                                            audio.play_death()
                                            if pieza_atacada in turn_manager.piezas_en_juego:
                                                turn_manager.piezas_en_juego.remove(pieza_atacada)
                                                nueva_anim_muerte = FadeOutAnimation(pieza_atacada)
                                                animaciones_muerte.append(nueva_anim_muerte)
                                                tablero[fila_clic][col_clic] = None
                                    
                                    pieza_activa.ha_atacado = True
                                    ataques_resaltados = []
                                    movimientos_resaltados = []
                                    
                                    # Calcular posiciones en pÃ­xeles CON offsets
                                    start_px = (constants.OFFSET_X + pieza_activa.posicion[1] * constants.TAMANO_CASILLA + constants.TAMANO_CASILLA / 2,
                                               constants.OFFSET_Y + pieza_activa.posicion[0] * constants.TAMANO_CASILLA + constants.UI_ALTO + constants.TAMANO_CASILLA / 2)
                                    target_px = (constants.OFFSET_X + col_clic * constants.TAMANO_CASILLA + constants.TAMANO_CASILLA / 2,
                                                constants.OFFSET_Y + fila_clic * constants.TAMANO_CASILLA + constants.UI_ALTO + constants.TAMANO_CASILLA / 2)
                                    
                                    if pieza_activa.tipo_ataque == 'melee':
                                        animacion_en_curso = MeleeAttackAnimation(pieza_activa, start_px, target_px, 30, aplicar_dano_callback)
                                        audio.play_melee_attack()
                                    elif pieza_activa.tipo_ataque == 'ranged':
                                        animacion_en_curso = ProjectileAnimation(pieza_activa, start_px, target_px, 40, aplicar_dano_callback)
                                        audio.play_ranged_cast()
                            
                            elif (fila_clic, col_clic) in movimientos_resaltados:
                                if not pieza_activa.ha_movido:
                                    vieja_fila, vieja_col = pieza_activa.posicion
                                    
                                    # Calcular posiciones en pÃ­xeles CON offsets
                                    start_px = (constants.OFFSET_X + vieja_col * constants.TAMANO_CASILLA + constants.TAMANO_CASILLA / 2,
                                               constants.OFFSET_Y + vieja_fila * constants.TAMANO_CASILLA + constants.UI_ALTO + constants.TAMANO_CASILLA / 2)
                                    end_px = (constants.OFFSET_X + col_clic * constants.TAMANO_CASILLA + constants.TAMANO_CASILLA / 2,
                                             constants.OFFSET_Y + fila_clic * constants.TAMANO_CASILLA + constants.UI_ALTO + constants.TAMANO_CASILLA / 2)
                                    
                                    animacion_en_curso = MoveAnimation(pieza_activa, start_px, end_px, 10)
                                    audio.play_move()
                                    
                                    tablero[vieja_fila][vieja_col] = None
                                    tablero[fila_clic][col_clic] = pieza_activa
                                    pieza_activa.posicion = (fila_clic, col_clic)
                                    pieza_activa.ha_movido = True
                                    
                                    movimientos_resaltados = []
                                    ataques_resaltados = []
        
        # --- Dibujado ---
        # Rellenar fondo si estamos en fullscreen
        if constants.MODO_FULLSCREEN:
            pantalla.fill((30, 30, 30))
        
        dibujar_tablero(pantalla)
        dibujar_borde_turno(pantalla, pieza_activa)
        
        if pieza_activa or animacion_en_curso:
            dibujar_resaltados(pantalla, movimientos_resaltados, ataques_resaltados, pieza_activa)
        
        dibujar_piezas(pantalla, tablero, pieza_activa, CACHE_IMAGENES, fuente_hp, animacion_en_curso)
        
        if animacion_en_curso:
            dibujar_animacion_activa(pantalla, animacion_en_curso, CACHE_IMAGENES)
        
        for animacion in animaciones_muerte:
            pieza = animacion.entidad
            alpha = animacion.get_alpha()
            
            from game.assets import crear_superficie_pieza
            color = (60, 60, 180) if pieza.jugador == 1 else (180, 60, 60)  # COLOR_J1_OPACO / COLOR_J2_OPACO
            imagen_original = crear_superficie_pieza(pieza.nombre, color, (int(constants.TAMANO_CASILLA*0.7), int(constants.TAMANO_CASILLA*0.7)), CACHE_IMAGENES)
            
            imagen_draw = imagen_original.copy()
            imagen_draw.set_alpha(alpha)
            centro_x = int(constants.OFFSET_X + pieza.posicion[1] * constants.TAMANO_CASILLA + constants.TAMANO_CASILLA / 2)
            centro_y = int(constants.OFFSET_Y + pieza.posicion[0] * constants.TAMANO_CASILLA + constants.UI_ALTO + constants.TAMANO_CASILLA / 2)
            rect_imagen = imagen_draw.get_rect(center=(centro_x, centro_y))
            pantalla.blit(imagen_draw, rect_imagen)
        
        dibujar_numeros_flotantes(pantalla, numeros_flotantes)
        dibujar_ui(pantalla, pygame.font.SysFont("Arial", 20), pieza_activa)
        dibujar_panel_turnos(pantalla, turn_queue, CACHE_IMAGENES, pygame.font.SysFont("Arial", int(16 * constants.ESCALA_GLOBAL)))
        
        pygame.display.flip()
        reloj.tick(constants.FPS)